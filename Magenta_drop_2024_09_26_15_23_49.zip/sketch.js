function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(175,100,220);
  rect(100,100,100,100);
  
}