function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(200);
  
  //rectangle
  fill(255, 200, 0)
  stroke(50,100,75)
  strokeWeight(20)
  rect(50, 100,100, 200)
 
}